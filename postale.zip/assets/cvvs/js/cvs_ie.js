function editLogin(){document.getElementById("val_cel_identifiant_hidden").className="input-non-modif cache";
document.getElementById("val_cel_identifiant").className="";
document.getElementById("val_cel_identifiant").focus()
}function activePlaceholderIe(b){if(b.value==""){document.getElementById("val_cel_identifiant_hidden").className="input-non-modif";
document.getElementById("val_cel_identifiant").className="webaccess"
}}function editMdp(){document.getElementById("cvs-bloc-mdp-input-hidden").className="cache";
document.getElementById("cvs-bloc-mdp-input").className=""
};